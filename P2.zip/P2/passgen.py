import os
from flask import Flask, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(BASE_DIR, 'database.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(25), unique=True, nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)

    def __repr__(self):
        return f"User('{self.username}', '{self.email}')"

# Homepage: list users
@app.route('/')
def index():
    users = User.query.all()
    user_list = "".join(
        f"<li>{u.username} ({u.email}) "
        f"<a href='/edit/{u.id}'>Edit</a> "
        f"<form action='/delete/{u.id}' method='POST' style='display:inline;'>"
        f"<button type='submit'>Delete</button></form></li>"
        for u in users
    )
    return f"""
        <h1>Users</h1>
        <ul>{user_list or '<li>No users yet</li>'}</ul>
        <a href='/register'>Register</a>
    """

# Register new user
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        user = User(username=username, email=email)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for('index'))
    return """
        <h1>Register User</h1>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <button type="submit">Register</button>
        </form>
    """

# Edit user
@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    user = User.query.get_or_404(id)
    if request.method == 'POST':
        user.username = request.form['username']
        user.email = request.form['email']
        db.session.commit()
        return redirect(url_for('index'))
    return f"""
        <h1>Edit User</h1>
        <form method="POST">
            <input type="text" name="username" value="{user.username}" required>
            <input type="email" name="email" value="{user.email}" required>
            <button type="submit">Save</button>
        </form>
    """

# Delete user
@app.route('/delete/<int:id>', methods=['POST'])
def delete(id):
    user = User.query.get_or_404(id)
    db.session.delete(user)
    db.session.commit()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)